num1 = input('Enter first number: ')
num2 = input('Enter second number: ')


sub = float(num1) - float(num2)

# Display the sub
print(sub)