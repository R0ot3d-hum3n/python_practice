num1 = input('Enter first number: ')
num2 = input('Enter second number: ')


div = num1 / num2

# Display the div
print(div)