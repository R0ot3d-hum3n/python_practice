# generate a random number between 0 and 9


import random

print(random.randint(0,9))