#This program adds two numbers
num1 = input('Enter first number: ')
num2 = input('Enter second number: ')


sum = float(num1) + float(num2)


print(sum)